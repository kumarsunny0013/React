import React, { Component } from 'react'
import Layout from './layout';
import Footer from './footer';

class About extends Component {
    user = null;
    componentWillMount = () => {
        let data = localStorage.getItem("user");
        if (data) {
            this.user = JSON.parse(localStorage.getItem('user'));
        }
    }

    render() {
        return (
            <div>
                <Layout data="about" name={this.user ? this.user.firstName : ""} />
                <h3 className="text-center">SUNNY KUMAR</h3>
                <Footer />
            </div>
        )
    }
}

export default About;