import React, { Component } from 'react';

class Footer extends Component {
    render() {
        return (
            <div className="text-center btn-primary"style={{marginTop:"440px",position:"relative"}}>
                <h4>&copy; SUNNY KUMAR</h4>
            </div>
        )
    }
}

export default Footer;