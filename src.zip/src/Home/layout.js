import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import About from './about';
import { userService } from '../Services/user.service';
class Layout extends Component {

    state = {
        flag: this.props.data
    }
    user = localStorage.getItem("user");
    active = (data) => {
        this.setState({ flag: data })
    }

    render() {
        return (
            <div className="header">
                <a href="/" className="logo"><img src="../infosys.jpg" style={{ width: "150px", height: "50px" }}></img></a>
                <div className="header-right">
                    <h3 className="">{this.props.name ? "Hi! " + this.props.name : ""}</h3>
                    {this.user ? <Link to="/" className={this.state.flag == "home" ? "active" : ""} >Home</Link> : null}
                    <Link to="/about" className={this.state.flag == "about" ? "active" : ""} ><b>About</b></Link>
                    {this.user ? <Link onClick={userService.logout} to="/login"><b>Logout</b></Link> :
                        <Link to="/login"><b>Login</b></Link>}
                    {/* <Redirect to={{ pathname: '/login', state: { from: props.location } }} /> */}
                </div>
            </div>
        )
    }
}

export default Layout;