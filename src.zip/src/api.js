const instance = axios.create({
    baseURL: 'https://api.example.com'
});